#pragma once

enum ENetError
{
	E_OK,
	E_COULDNT_START_CLIENT,
	E_COULDNT_CREATE_PEER
};