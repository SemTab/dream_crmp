#pragma once

void SetRadarColor(int nIndex, uint32_t dwColor);
void GameResetRadarColors();
uint32_t TranslateColorCodeToRGBA(int iCode);