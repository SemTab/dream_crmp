#pragma once

// RPC
#define RPC_SPAWN_SELECT  0x36
#define sendRPC_SPAWNSELECTOR	0x42

class CSpawnSelector
{
public:
	static void Show(int home, int fraction);
};

