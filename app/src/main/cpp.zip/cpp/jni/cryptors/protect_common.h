#pragma once
#include <mutex>
extern std::mutex g_MiscProtectMutex;